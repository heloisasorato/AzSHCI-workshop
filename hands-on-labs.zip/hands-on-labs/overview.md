# Azure Stack HCI 20H2 with Azure

### Setup the lab on your own Azure Subscription.

 Please follow the below step to setup and perform the lab in your subscription.
 
 1. Please follow this GitHub repo and peform all the mentioned steps https://github.com/mattmcspirit/hybridworkshop, to setup the environment for Azure Stack HCI 20H2.
